## Skill 分发：清单哈希 + 漂移检测 + 同步脚本入库（2026-09-25）

task 1141f101 ｜ 链 bf5088a3 棒8 ｜ 决策 105a5868

### 根本原因

- **「条目数一致」被当成「内容一致」**：MMV 的 `~/.claude/skills` 顶层几乎全是指向 zenithjoy-skills 的符号链接，本机 cron 用 `rsync -a`（无 `-L`）把链接原样拷到跑场机，目标机上全部悬空（M1 133/133）。数条目 135=135 判对齐，内容其实为零，经跑场池下放的会话没有可用 skill。
- **同步动作没有回读校验**：cron 没有 `--delete`、没有同步后重算比对、行也不在仓库，本机私有无 review 无测试，坏了没人知道。
- **真身自己也有病**：MMV 上 29 个悬空链接（目标目录不存在）。若把它们算进清单哈希，任何目标都永远对不齐；必须单列，不进 tree_hash。
- **真机 dry-run 才暴露的两处**：跑场机上 python skill 运行时自己生成 `__pycache__`，不排除会永久假漂移；`rsync --exclude` 排除悬空名会让目标上同名残留被排除规则保护、`--delete` 删不掉，改成临时目录里只放有内容 skill 的符号链接视图。
- **CI 门禁按文件类型有盲区**：`src/` 下的 `.sh` 没有 import 边被 island-gate 判孤岛，`src/lib/*.js` 必须有同目录 `__tests__` 配对测试（lint-test-pairing）；被 Brain 运行时读的脚本应放 repo 根 `scripts/` 并在 Dockerfile 显式 COPY。
- **测试里的调度全量跑会真发 ssh**：`scheduler-jobs.test.js` 逐个执行 JOBS 里所有 handler，新 job 若不 mock 会在单测里真连 ssh（该文件从 42ms 变成 19s 才发现）。

### 下次预防

- [ ] 任何「多机对齐」检测一律按内容哈希比对（跟随符号链接），禁止只数条目；悬空链接单列，不当作存在也不当作零个。
- [ ] 任何同步脚本必须在同步后重算目标清单并与真身比对，不一致非零退出；默认 dry-run，破坏性开关（`--prune`）显式传。
- [ ] 远端探测失败必须落成 `unreachable`（未核对），绝不折算成「零个」再去算漂移或触发删除。
- [ ] 新增 scheduler job 时同步检查 `scheduler-jobs.test.js` 的 handler mock 列表；凡会 ssh/exec 的 job 必须 mock，并另配注入假执行器的单测。
- [ ] 设计同步/清单口径前先对真机做只读 dry-run，看运行时产物（字节码、eval 输出、暂存目录）会不会制造永久漂移。
