# test-skill
测试用 skill zip，用于 BEHAVIOR 测试。
platform: claude
line: Line00
